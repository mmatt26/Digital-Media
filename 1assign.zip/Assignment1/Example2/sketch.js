function setup() {
  createCanvas(200, 200);
}

function draw() {
  background(255);
   noStroke();
   fill(0, 0, 255, 90);
   ellipse(70, 130 , 110, 110);
   fill(0, 255, 0, 90);
   ellipse(140, 130 , 110, 110);
   fill(255, 0, 0, 90);
   ellipse(105, 70 , 110, 110);
}
