function setup() {
  createCanvas(200, 100);
}

function draw() {
  background(80, 255, 0);
  ellipse(50, 50, 85, 85);
  rect(110, 10, 80, 80 );
}
